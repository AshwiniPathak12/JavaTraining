package com.yash.oas.controller;

import java.util.List;

import javax.validation.Valid;

import com.yash.oas.model.Admin;
import com.yash.oas.model.Agent;

import com.yash.oas.repository.AgentRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/Agent")
@CrossOrigin(origins = {"http://localhost:4200"},maxAge = 4800, allowCredentials = "false")  
public class AgentController {

	// Inject AdminService Class
	@Autowired
	AgentRepo agentrepo;

	// get all AdminDetails details
	@GetMapping("/getagent")
	public List<Agent> getAllAgent() {
		return agentrepo.findAll();
	}
	
	// To get the policy details of user by using user id.
			@GetMapping("/getagent/{id}")
			public ResponseEntity<Agent> getAgentById(@PathVariable Integer id) {
				Agent agent = agentrepo.getById(id);
				return ResponseEntity.ok().body(agent);
			}
			
			// save insurance details
			@PostMapping("/saveagent")
			public Agent saveagent(@RequestBody Agent agent) {
				Agent getagent = agentrepo.save(agent);
				return getagent;
			}
			
			// update insurance details
			@PutMapping("/updateagent/{id}")
			public ResponseEntity<Agent> updateAgent(@PathVariable("id") Integer id,
					@RequestBody Agent agent) {
				Agent agent1 = agentrepo.getById(id);//findbyid			
				agent1.setId(agent.getId());
				agent1.setName(agent.getName());
				agent1.setCommission(agent.getCommission());
				
				Agent updateagent = agentrepo.save(agent1);
				return ResponseEntity.ok().body(updateagent);
			}

			// To delete the policy details of user by using id.
			@DeleteMapping("/delete/{id}")
			public String deleteAgentById(@PathVariable("id") Integer id)  {
			Agent getagent=agentrepo.getById(id);
			agentrepo.delete(getagent);
			return "Record deleted successfully....!!!!!!";
			}
			
			 @PostMapping("/login")
			 public AgentStatus loginAgent(@Valid @RequestBody Agent agent) {
			     
				 Agent OldAgent=agentrepo.findbyEmailId(agent.getEmail());
			        System.out.println(OldAgent);
			        
			        if(OldAgent!=null) {
			        	if(OldAgent.getPassword().equals(agent.getPassword())) {
			        		return AgentStatus.SUCCESS;
			        	}else {
			        		 return AgentStatus.FAILURE;
			        	}
			        }
			        return AgentStatus.FAILURE;
			 }

}
