package com.yash.oas.service;

import java.util.ArrayList;
import java.util.List;
import com.yash.oas.exception.UserNotFoundException;
import com.yash.oas.model.Admin;
import com.yash.oas.repository.AdminRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminService {
	// InjectAdminRepo Interface
	@Autowired
	private final AdminRepo adminrepo;

	public AdminService(AdminRepo adminrepo) {
		this.adminrepo = adminrepo;
	}

	// get all Admin details

	public List<Admin> getAllAdmin() {
		return adminrepo.findAll();
	}

	// get Admin details by using Id

	public Admin getAdminById(int id) {
		return adminrepo.findById(id).orElseThrow(() -> new UserNotFoundException("user by id " + id + " not found"));
	}

	// Save single Admin details
	public Admin saveAdmin(Admin admin) {
		return adminrepo.save(admin);
	}

	// To Update the Admin details
	public Admin updateAdmin(Admin admin) {
		return adminrepo.save(admin);
	}

	// delete admin on the basis of Id
	public void deleteAdminById(int id) {
		adminrepo.deleteById(id);
		System.out.println("Deleted Successfully....!!!!!");

	}

}