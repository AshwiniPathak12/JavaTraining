package com.yash.oas.repository;

import com.yash.oas.model.Insurance;

import org.springframework.data.jpa.repository.JpaRepository;

public interface InsuranceRepo extends JpaRepository<Insurance, Integer> {

}