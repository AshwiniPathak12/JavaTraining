package com.yash.oas.repository;

import com.yash.oas.model.Agent;
import com.yash.oas.model.User;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface UserRepo extends JpaRepository<User, Integer> {

	
	@Query("From User a where a.email=:email")
	User findbyEmailId(@Param("email") String email);
}