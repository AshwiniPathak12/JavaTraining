package com.yash.oas.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({ "hibernateLazyInitializer" }) // add this bcoz find error for fetch data by id
@Entity
@Table(name = "Insurance")
public class Insurance implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String insurancenumber;
	private String insurancepremiumamount;
	private String email;
	private String claimnumber;
	private String status;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getInsurancenumber() {
		return insurancenumber;
	}

	public void setInsurancenumber(String insurancenumber) {
		this.insurancenumber = insurancenumber;
	}

	public String getInsurancepremiumamount() {
		return insurancepremiumamount;
	}

	public void setInsurancepremiumamount(String insurancepremiumamount) {
		this.insurancepremiumamount = insurancepremiumamount;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getClaimnumber() {
		return claimnumber;
	}

	public void setClaimnumber(String claimnumber) {
		this.claimnumber = claimnumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Insurance() {
	}

	@Override
	public String toString() {
		return "Insurance [insurance_id=" + id + ", insurancenumber=" + insurancenumber
				+ ", insurancepremiumamount=" + insurancepremiumamount + ", email=" + email + ", claimnumber="
				+ claimnumber + ", status=" + status + "]";
	}

}