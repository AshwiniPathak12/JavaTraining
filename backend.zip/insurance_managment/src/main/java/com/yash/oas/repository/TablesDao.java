//package com.yash.oas.repository;
//
//import com.sun.istack.NotNull;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.stereotype.Service;
////add on 27
//@Service
//public class TablesDao {
//
//	@Autowired
//	JdbcTemplate jdbcTemplate;
//	
//	public String createAllTables() {
//		String query1 = "CREATE TABLE IF NOT EXISTS Admin"
//				+ "(" + "admin_id INT  NOT NULL  AUTO_INCREMENT,"
//				+ "name  VARCHAR(50)  NOT NULL," 
//				+ "mobile_no VARCHAR(50) NOT NULL UNIQUE,"
//				+ "email VARCHAR(50) NOT NULL," 
//				+ "password VARCHAR(50) NOT NULL,"
//				+ "PRIMARY KEY (admin_id))";
//
//			    
//		    String query2 = "CREATE TABLE IF NOT EXISTS Agent"
//					+ "(" + "agent_id INT  NOT NULL  AUTO_INCREMENT,"
//					+ "name  VARCHAR(50)  NOT NULL," 
//					+ "commission  VARCHAR(50)  NOT NULL,"
//					+ "city  VARCHAR(50)  NOT NULL,"					
//					+ "mobile_no VARCHAR(50) NOT NULL UNIQUE,"
//					+ "email VARCHAR(50) NOT NULL," 
//					+ "password VARCHAR(50) NOT NULL,"
//					+ "PRIMARY KEY (agent_id))";
//		    
//		    String query3 = "CREATE TABLE IF NOT EXISTS User"
//					+ "(" + "user_id INT  NOT NULL  AUTO_INCREMENT,"
//					+ "name  VARCHAR(50)  NOT NULL," 
//					+ "email VARCHAR(50) NOT NULL,"
//					+ "dob  VARCHAR(50)  NOT NULL,"
//					+ "address  VARCHAR(50)  NOT NULL,"					
//					+ "gender VARCHAR(10) NOT NULL ,"
//					 
//					+ "password VARCHAR(50) NOT NULL,"
//					+ "PRIMARY KEY (user_id))";
//		    
//		    String query4 = "CREATE TABLE IF NOT EXISTS Insurance"
//					+ "(" + "insurance_id INT  NOT NULL  AUTO_INCREMENT,"
//					+ "insurancenumber  VARCHAR(50)  NOT NULL,"
//					+ "insurancepremiumamount  VARCHAR(50),"
//					+ "email VARCHAR(50) NOT NULL,"					
//					+ "claimnumber  VARCHAR(50)  NOT NULL,"					
//					+ "status VARCHAR(10) NOT NULL ,"					 
//					+ "password VARCHAR(50) NOT NULL,"
//					+ "PRIMARY KEY (insurance_id))";
//		    
//		
////
////		    String query5 = "CREATE TABLE IF NOT EXISTS Bill2"
////					+ "(" + "bill_id INT NOT NULL AUTO_INCREMENT,"
////					+ "balance VARCHAR(50),"
////					+ "created_date VARCHAR(50),"
////					+ "status VARCHAR(10) NOT NULL,"
////					+"PRIMARY KEY(bill_id),"
////					+"CONSTRAINT FK_insurance_id1 FOREIGN KEY(insurance_id) REFERENCES Insurance(insurance_id)";
////					+"user_id FOREIGN KEY REFERENCES User(user_id))";
//		 
//		    
//		this.jdbcTemplate.update(query1);
//		this.jdbcTemplate.update(query2);
//		this.jdbcTemplate.update(query3);
//		this.jdbcTemplate.update(query4);
//		//this.jdbcTemplate.update(query5);
//		return "Tables Created...";
//	}
//
//}
