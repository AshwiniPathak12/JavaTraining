package com.yash.oas.controller;

public enum UserStatus {

	SUCCESS,
    Admin_ALREADY_EXISTS,
    FAILURE
}
