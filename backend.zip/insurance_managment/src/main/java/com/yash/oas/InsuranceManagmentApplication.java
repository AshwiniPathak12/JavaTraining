package com.yash.oas;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties
@EntityScan(basePackages = { "com.yash.oas.model" })

//implements CommandLineRunner
public class InsuranceManagmentApplication {
	
//	@Autowired
//	TablesDao tablesDao;

	public static void main(String[] args) {
		SpringApplication.run(InsuranceManagmentApplication.class, args);
	}

	// extra add on 27
//	@Override
//	public void run(String... args) throws Exception {
//		System.out.println(this.tablesDao.createAllTables());
//		
//	}

}
