package com.yash.oas.exception;

public class InsuranceTypeException extends Exception {

	public InsuranceTypeException(String string) {
		super(string);
	}

}
