package com.yash.oas.controller;

public enum AgentStatus {

	SUCCESS,
    Admin_ALREADY_EXISTS,
    FAILURE
    
}
