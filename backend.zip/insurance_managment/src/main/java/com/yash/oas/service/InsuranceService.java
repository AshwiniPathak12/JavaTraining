//package com.yash.oas.service;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import com.yash.oas.model.Insurance;
//import com.yash.oas.repository.InsuranceRepo;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//@Service
//public class InsuranceService {
//
//	@Autowired
//	private InsuranceRepo insurancerepo;
//	
//	// getall user details by using the method findaAll() of CrudRepository
//
//		public List<Insurance> getAllUser() {
//			List<Insurance> insurance = new ArrayList<Insurance>();
//			return insurancerepo.findAll();
//
//		}
//
//	// Save single user details
//
//	public Insurance save(Insurance insurance) {
//
//		return insurancerepo.save(insurance);
//	}
//
//	
//
//	// getall user details by using the method findById() of CrudRepository
//
//	public Insurance getInsuranceById(int id) {
//		return insurancerepo.findById(id).get();
//		// ("User", "id", id));
//	}
//	
//	//update insurance
//    public void update(Insurance insurance, int id) {
//        insurancerepo.save(insurance);
//    }
//
//	public void deleteInsuranceById(int id) {
//		insurancerepo.deleteById(id);
//		System.out.println("Deleted Successfully....!!!!!");
//		// ("User", "id", id));
//	}
//
//	public Insurance saveInsurance(Insurance insurance) {
//
//		return insurancerepo.save(insurance);
//	}
//
//}