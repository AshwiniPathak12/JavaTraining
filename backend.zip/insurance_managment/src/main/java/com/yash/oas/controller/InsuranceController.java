package com.yash.oas.controller;

import java.util.List;

import com.yash.oas.model.Insurance;
import com.yash.oas.repository.InsuranceRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/Insurance")
@CrossOrigin(origins = "http://localhost:4200")
public class InsuranceController {

	@Autowired
	InsuranceRepo insuranceRepo;

	// get all insurnace details
	@GetMapping("/getinsurance")
	public List<Insurance> getAllInsurance() {
		return insuranceRepo.findAll();
	}

	// To get the policy details of user by using user id.
	@GetMapping("/getinsurance/{id}")
	public ResponseEntity<Insurance> getInsuranceById(@PathVariable Integer id) {

		Insurance insurance = insuranceRepo.getById(id);
		return ResponseEntity.ok().body(insurance);
	}

	// save insurance details
	@PostMapping("/saveinsurance")
	public Insurance saveinsurance(@RequestBody Insurance insurance) {
		Insurance getinsurance = insuranceRepo.save(insurance);
		return getinsurance;
	}

	// update insurance details
	@PutMapping("/updateinsurances/{id}")
	public ResponseEntity<Insurance> updateInsurance(@PathVariable("id") Integer id, @RequestBody Insurance insurance) {
		Insurance getinsurance1 = insuranceRepo.getById(id);//findbyid
		
		getinsurance1.setInsurancenumber(insurance.getInsurancenumber());
		getinsurance1.setInsurancepremiumamount(insurance.getInsurancepremiumamount());
		getinsurance1.setEmail(insurance.getEmail());
		getinsurance1.setStatus(insurance.getStatus());
		getinsurance1.setClaimnumber(insurance.getClaimnumber());
		
		Insurance updateinsurance = insuranceRepo.save(getinsurance1);
		return ResponseEntity.ok().body(updateinsurance);
	}
	
	
	// To delete the policy details of user by using id.
	@DeleteMapping("/delete/{id}")
	public String deleteInsuranceById(@PathVariable("id") Integer id)  {
	Insurance getinsuranc=insuranceRepo.getById(id);
	insuranceRepo.delete(getinsuranc);
	return "Record deleted successfully....!!!!!!";
	}
//		insuranceservice.deleteInsuranceById(id);

	

//	/*
//	 * public ResponseEntity<Optional<Insurance>>
//	 * getAllInsuranceById(@PathVariable("id") Integer id) throws
//	 * InsuranceTypeException { Optional<Insurance> insurance =
//	 * insuranceservice.getInsuranceById(id); return
//	 * ResponseEntity.ok().body(insurance); }
//	 */
//
//	
//
//	// creating put mapping that updates the book detail
//	@PutMapping("/insurances")
//	private Insurance update(@RequestBody Insurance insurance) {
//		insuranceservice.save(insurance);
//		return insurance;
//	}
//
//	// To delete the policy details of user by using id.
//	@DeleteMapping("/delete/{id}")
//	public void deleteInsuranceById(@PathVariable("id") Integer id) throws Exception {
//		insuranceservice.deleteInsuranceById(id);
//	}

}