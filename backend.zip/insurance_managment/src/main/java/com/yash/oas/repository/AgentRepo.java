package com.yash.oas.repository;



import com.yash.oas.model.Agent;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface AgentRepo extends JpaRepository<Agent, Integer> {

	@Query("From Agent a where a.email=:email")
	Agent findbyEmailId(@Param("email") String email);

}