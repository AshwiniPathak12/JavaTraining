package com.yash.oas.controller;

public enum AdminStatus {

	
	SUCCESS,
    Admin_ALREADY_EXISTS,
    FAILURE
}
