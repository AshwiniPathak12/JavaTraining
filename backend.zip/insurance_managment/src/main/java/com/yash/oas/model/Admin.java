package com.yash.oas.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sun.istack.NotNull;

@JsonIgnoreProperties({ "hibernateLazyInitializer" }) // add this bcoz find error for fetch data by id
@Entity
@Table(name = "Admin")
public class Admin implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, updatable = false)
	private int id;
	private String name;
	private String mobile_no;

	
	private boolean loggedIn;
	private @NotNull String email;
	private @NotNull String password;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isLoggedIn() {
		return loggedIn;
	}

	public void setLoggedIn(boolean loggedIn) {
		this.loggedIn = loggedIn;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobile_no() {
		return mobile_no;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	public Admin() {
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, name, password, loggedIn);
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if (this == obj)
			return true;
		if (!(obj instanceof Admin))
			return false;
		Admin admin = (Admin) obj;
		return Objects.equals(name, admin.name) && Objects.equals(password, admin.password);
	}

	@Override
	public String toString() {
		return "Admin [admin_id=" + id + ", name=" + name + ", loggedIn=" + loggedIn + ", email=" + email
				+ ", password=" + password + "]";
	}

}
