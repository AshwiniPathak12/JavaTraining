package com.yash.oas.controller;

import java.util.List;

import javax.validation.Valid;

import com.yash.oas.model.Admin;
import com.yash.oas.model.User;
import com.yash.oas.repository.AdminRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ch.qos.logback.core.status.Status;

@RestController
@RequestMapping("/Admin")
@CrossOrigin(origins = "http://localhost:4200")
public class AdminController {

	// Inject AdminService Class
	@Autowired
	AdminRepo adminrepo;

	// get all AdminDetails details
	@GetMapping("/getadmin")
	public List<Admin> getAllAdmin() {
		return adminrepo.findAll();
	}

	// To get the policy details of user by using user id.
	@GetMapping("/getadmin/{id}")
	public ResponseEntity<Admin> getAdminById(@PathVariable Integer id) {
		Admin admin = adminrepo.getById(id);
		return ResponseEntity.ok().body(admin);
	}

	// save insurance details
	@PostMapping("/saveadmin")
	public Admin saveadmin(@RequestBody Admin admin) {
		Admin getadmin = adminrepo.save(admin);
		return getadmin;
	}

	// update insurance details
	@PutMapping("/updateadmin/{id}")
	public ResponseEntity<Admin> updateAdmin(@PathVariable("id") Integer id, @RequestBody Admin admin) {
		Admin admin1 = adminrepo.getById(id);// findbyid
		admin1.setId(admin.getId());
		admin1.setName(admin.getName());
		Admin updateadmin = adminrepo.save(admin1);
		return ResponseEntity.ok().body(updateadmin);
	}

	// To delete the policy details of user by using id.
	@DeleteMapping("/delete/{id}")
	public String deleteAdminById(@PathVariable("id") Integer id) {
		Admin getadmin = adminrepo.getById(id);
		adminrepo.delete(getadmin);
		return "Record deleted successfully....!!!!!!";
	}

	//To login the policy 
	@PostMapping("/login")
	public AdminStatus loginAdmin(@Valid @RequestBody Admin admin) {		
		Admin adminOld = adminrepo.findbyEmailId(admin.getEmail());
		System.out.println(adminOld);

		if (adminOld != null) {
			if (adminOld.getPassword().equals(admin.getPassword())) {
				return AdminStatus.SUCCESS;
			} else {
				return AdminStatus.FAILURE;
			}
		}

		return AdminStatus.FAILURE;
	}

//		 @PostMapping("/register")
//		    public AdminStatus registerAdmin(@Valid @RequestBody Admin newAdmin) {
//		        List<Admin> admins = adminrepo.findAll();
//		        System.out.println("New admin: " + newAdmin.toString());
//		        for (Admin admin : admins) {
//		            System.out.println("Registered user: " + newAdmin.toString());
//		            if (admin.equals(newAdmin)) {
//		                System.out.println("User Already exists!");
//		               // return Status.USER_ALREADY_EXISTS;
//		                return AdminStatus.Admin_ALREADY_EXISTS;
//		            }
//		        }
//		        adminrepo.save(newAdmin);
//		        //return Status.SUCCESS;
//				return AdminStatus.SUCCESS;		        
//		    }
//		 

//	        for (Admin other : admins) {
//	            if (other.equals(admin)) {
//	                admin.setLoggedIn(true);
//	                adminrepo.save(admin);
//	                return AdminStatus.SUCCESS;
//	                }
//	        }

//		 @PostMapping("/logout")
//		    public AdminStatus logAdminOut(@Valid @RequestBody Admin admin) {
//		        List<Admin> admins = adminrepo.findAll();
//		        for (Admin other : admins) {
//		            if (other.equals(admin)) {
//		                admin.setLoggedIn(false);
//		                adminrepo.save(admin);
//		                return AdminStatus.SUCCESS;
//		            }
//		        }
//		        return AdminStatus.FAILURE;
//		    }
}