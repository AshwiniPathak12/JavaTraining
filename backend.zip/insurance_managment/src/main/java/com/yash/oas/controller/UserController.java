package com.yash.oas.controller;

import java.util.List;

import javax.validation.Valid;

import com.yash.oas.model.Agent;
import com.yash.oas.model.User;
import com.yash.oas.repository.UserRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/User")
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {

	@Autowired
	UserRepo userrepo;

	// get all AdminDetails details
	@GetMapping("/getuser")
	public List<User> getAllUser() {
		return userrepo.findAll();
	}

	// To get the policy details of user by using user id.
	@GetMapping("/getuser/{id}")
	public ResponseEntity<User> getUserById(@PathVariable Integer id) {
		User user = userrepo.getById(id);
		return ResponseEntity.ok().body(user);
	}

	// save insurance details
	@PostMapping("/saveuser")
	public User saveuser(@RequestBody User user) {
		User getuser = userrepo.save(user);
		return getuser;
	}

	// update insurance details
	@PutMapping("/updateuser/{id}")
	public ResponseEntity<User> updateUser(@PathVariable("id") Integer id, @RequestBody User user) {
		User user1 = userrepo.getById(id);// findbyid
		user1.setId(user.getId());
		user1.setName(user.getName());
		user1.setEmail(user.getEmail());
		user1.setDob(user.getDob());
		user1.setAddress(user.getAddress());
		user1.setGender(user.getGender());
		user1.setPassword(user.getPassword());

		User updateuser = userrepo.save(user1);
		return ResponseEntity.ok().body(updateuser);
	}

	// To delete the policy details of user by using id.
	@DeleteMapping("/delete/{id}")
	public String deleteUserById(@PathVariable("id") Integer id) {
		User getuser = userrepo.getById(id);
		userrepo.delete(getuser);
		return "Record deleted successfully....!!!!!!";
	}
	
	 @PostMapping("/login")
	 public UserStatus loginUser(@Valid @RequestBody User user) {
	     
		 User OldUser=userrepo.findbyEmailId(user.getEmail());
	        System.out.println(userrepo);
	        
	        if(OldUser!=null) {
	        	if(OldUser.getPassword().equals(user.getPassword())) {
	        		return UserStatus.SUCCESS;
	        	}else {
	        		 return UserStatus.FAILURE;
	        	}
	        }
	        return UserStatus.FAILURE;
	 }

}
