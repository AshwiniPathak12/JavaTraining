import { getInstructionStatements } from '@angular/compiler/src/render3/view/util';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule, Routes } from '@angular/router';
import { GetInsuranceComponent } from './get-insurance/get-insurance.component';
import { SaveInsuranceComponent } from './save-insurance/save-insurance.component';
import { UpdateInsuranceComponent } from './update-insurance/update-insurance.component';
import { LoginbuttonComponent } from './loginbutton/loginbutton.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AgentSignupComponent } from './agent-signup/agent-signup.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { AdminListComponent } from './admin-list/admin-list.component';
import { AgentListComponent } from './agent-list/agent-list.component';
import { UserListComponent } from './user-list/user-list.component';
import { SaveAdminComponent } from './save-admin/save-admin.component';
import { SaveAgentComponent } from './save-agent/save-agent.component';
import { SaveUserComponent } from './save-user/save-user.component';
import { UpdateAdminComponent } from './update-admin/update-admin.component';
import { UpdateAgentComponent } from './update-agent/update-agent.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { PolicyListComponent } from './policy-list/policy-list.component';
import { AdminOptionLoginComponent } from './admin-option-login/admin-option-login.component';
import { AdminLoginFormComponent } from './admin-login-form/admin-login-form.component';
import { AgentLoginFormComponent } from './agent-login-form/agent-login-form.component';
import { AgentOptionLoginFormComponent } from './agent-option-login-form/agent-option-login-form.component';
import { UserLoginFormComponent } from './user-login-form/user-login-form.component';
import { UserOptionLoginComponent } from './user-option-login/user-option-login.component';
import { Buypolicy1Component } from './buypolicy1/buypolicy1.component';
import { Buyprocess2Component } from './buyprocess2/buyprocess2.component';
import { Buyprocess3Component } from './buyprocess3/buyprocess3.component';
import { PaymentComponent } from './payment/payment.component';
import { AgentPolicyListViewRoleComponent } from './agent-policy-list-view-role/agent-policy-list-view-role.component';
import { HealthInsuranceInfoComponent } from './health-insurance-info/health-insurance-info.component';

const routes: Routes = [
  {path:'get-insurance',component:GetInsuranceComponent},
  {path:'save-insurance',component:SaveInsuranceComponent},
  {path:'update-insurance',component:UpdateInsuranceComponent},
  {path:'app-loginbutton',component:LoginbuttonComponent},
  {path:'app-adminlogin',component:AdminloginComponent},
  {path:'agent-signup',component:AgentSignupComponent},
  {path:'user-signup',component:UserSignupComponent},
  {path:'admin-list',component:AdminListComponent},
  {path:'agent-list',component:AgentListComponent},
  {path:'user-list',component:UserListComponent},
  {path:'save-admin',component:SaveAdminComponent},
  {path:'save-agent',component:SaveAgentComponent},
  {path:'save-user',component:SaveUserComponent},
  {path:'update-admin',component:UpdateAdminComponent},
  {path:'update-agent',component:UpdateAgentComponent},
  {path:'update-user',component:UpdateUserComponent},
  {path:'policy-list',component:PolicyListComponent},
  {path:'admin-login-form',component:AdminLoginFormComponent},
  {path:'admin-option-login',component:AdminOptionLoginComponent},
  {path:'agent-login-form',component:AgentLoginFormComponent},
  {path:'agent-option-login-form',component:AgentOptionLoginFormComponent},
  {path:'user-login-form',component:UserLoginFormComponent},
  {path:'user-option-login',component:UserOptionLoginComponent},
  {path:'buypolicy1',component:Buypolicy1Component},
  {path:'buyprocess2',component:Buyprocess2Component},
  {path:'buyprocess3',component:Buyprocess3Component},
  {path:'payment',component:PaymentComponent},
  {path:'agent-policy-list-view-role',component:AgentPolicyListViewRoleComponent},
  {path:'health-insurance-info',component:HealthInsuranceInfoComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
