import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Agent } from 'http';
import { Observable } from 'rxjs';
import { Agents } from './agent';

@Injectable({
  providedIn: 'root'
})
export class AgentService {
  id?:number;

  baseurl="http://localhost:8089/Agent/getagent";
  constructor(private httpClient:HttpClient) { }

//get
  getAllAgent():Observable<Agents[]>{
    return this.httpClient.get<Agents[]>(`${this.baseurl}`);
  }

  //save
  addAgent(agent?:Agents):Observable<Object>{
    return this.httpClient.post<Object>(`http://localhost:8089/Agent/saveagent`,agent);
  }

  //get agent by id update
getId(getid?:number){
this.id=getid;
}  
  //http://localhost:8089/Agent/getagent/2
  getAgentById():Observable<Object>{
    return this.httpClient.get<Object>(`${this.baseurl}/${this.id}`);
  }
  baseurl3="http://localhost:8089/Agent/updateagent";
  updateAgent(agent?:Agents):Observable<Object>{
    return this.httpClient.put<Object>(`${this.baseurl3}/${this.id}`,agent);
  }

  //delete

  baseurl4="http://localhost:8089/Agent/delete";
  deleteAgentById(id?:number):Observable<Object>{
    
    return this.httpClient.delete<Object>(`${this.baseurl4}/${this.id}`);
    
  }

//login Agent

loginAgent(agent?:Agents):Observable<Object>{
  return this.httpClient.post<Object>(`http://localhost:8089/Agent/login`,agent);
}

}
