import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentPolicyListViewRoleComponent } from './agent-policy-list-view-role.component';

describe('AgentPolicyListViewRoleComponent', () => {
  let component: AgentPolicyListViewRoleComponent;
  let fixture: ComponentFixture<AgentPolicyListViewRoleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgentPolicyListViewRoleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentPolicyListViewRoleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
