import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Insurance } from '../insurance';
import { InsuranceService } from '../insurance.service';

@Component({
  selector: 'app-agent-policy-list-view-role',
  templateUrl: './agent-policy-list-view-role.component.html',
  styleUrls: ['./agent-policy-list-view-role.component.css']
})
export class AgentPolicyListViewRoleComponent implements OnInit {
  insurance?:Insurance[];
  constructor(private router:Router,
    private insuranceservice:InsuranceService) { }

  ngOnInit(): void {

    this.getAllInsurance();
  }

  getAllInsurance(){
    this.insuranceservice.getAllInsurance().subscribe(data=>{
      this.insurance=data;
    });
  }

  BuyInsurance(){
    this.router.navigateByUrl('buypolicy1');
  }

}
