import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { Insurance } from '../insurance';
import { InsuranceService } from '../insurance.service';
//import { Router } from '@angular/router';

@Component({
  selector: 'app-get-insurance',
  templateUrl: './get-insurance.component.html',
  styleUrls: ['./get-insurance.component.css']
})
export class GetInsuranceComponent implements OnInit {
insurance?:Insurance[];
  
  constructor(private router:Router,private insuranceservice:InsuranceService) { }

  ngOnInit(): void {
  
    
  this.getAllInsurances();
 this.updateInsuranceRecord();

  }
// s to difference between getallinsurance n getallinsurances
  getAllInsurances(){
           this.insuranceservice.getAllInsurance().subscribe(data=>{
           this.insurance=data;
});
  }

  updateInsuranceRecord(id?:number){
    //var temp=id;
    console.log("id =",id);
    this.router.navigate(['update-insurance',id]);
  }

}
