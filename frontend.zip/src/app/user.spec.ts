import { Users } from './user';

describe('User', () => {
  it('should create an instance', () => {
    expect(new Users()).toBeTruthy();
  });
});
