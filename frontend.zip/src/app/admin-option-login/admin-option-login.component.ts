import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-option-login',
  templateUrl: './admin-option-login.component.html',
  styleUrls: ['./admin-option-login.component.css']
})
export class AdminOptionLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
