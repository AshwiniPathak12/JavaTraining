import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminOptionLoginComponent } from './admin-option-login.component';

describe('AdminOptionLoginComponent', () => {
  let component: AdminOptionLoginComponent;
  let fixture: ComponentFixture<AdminOptionLoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminOptionLoginComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminOptionLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
