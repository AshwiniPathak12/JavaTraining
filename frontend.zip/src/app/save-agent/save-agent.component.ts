import { Component, OnInit } from '@angular/core';
import { Agent } from 'http';
import { Agents } from '../agent';
import { AgentService } from '../agent.service';

@Component({
  selector: 'app-save-agent',
  templateUrl: './save-agent.component.html',
  styleUrls: ['./save-agent.component.css']
})
export class SaveAgentComponent implements OnInit {

agent:Agents=new Agents();
  constructor(private agentservice:AgentService) { }

  ngOnInit(): void {

  }

  saveagent(){
    console.log(this.agent);
    
    this.agentservice.addAgent(this.agent).subscribe();
    
    alert("Success...!!");
  }


}
