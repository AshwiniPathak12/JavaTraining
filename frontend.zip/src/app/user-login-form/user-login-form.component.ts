import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Users } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-login-form',
  templateUrl: './user-login-form.component.html',
  styleUrls: ['./user-login-form.component.css']
})
export class UserLoginFormComponent implements OnInit {
  user:Users=new Users();
  constructor(private router:Router,
    private userservice:UserService) { }

  ngOnInit(): void {
  }

  checkuserlogin(){
    //user-option-login
    //this.router.navigate(['user-option-login']);
    //check from here
     console.log(this.user);    
     this.router.navigate(['user-option-login']);

    // //var result= this.agentservice.loginAgent(this.agents).subscribe(response => {
     var result= this.userservice.loginAgent(this.user).subscribe(response => {    
      console.log(response);     
       
       if(response=="SUCCESS") 
       {     
        this.router.navigateByUrl('/buypolicy1');      
       }
       else{
         alert("enter valid creditial");
         this.router.navigateByUrl('/user-login-form');
       }       
     },
     error => {     
    //console.log(error);
     });
  }

  loginUser(user?:Users){
    //console.log("id",id);
     var result=this.userservice.getAllUser();
     console.log("sds",result);
    //  this.router.navigate(['admin']);
        
     }

}
