import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Agents } from '../agent';
import { AgentService } from '../agent.service';

@Component({
  selector: 'app-agent-list',
  templateUrl: './agent-list.component.html',
  styleUrls: ['./agent-list.component.css']
})
export class AgentListComponent implements OnInit {
    agent?:Agents[];
  
  constructor(private agentservice:AgentService,
              private router:Router) { }

  ngOnInit(): void {
   this.getAllAgents();
  }

  getAllAgents(){
    this.agentservice.getAllAgent().subscribe(data=>{
      this.agent=data;
    });

    
  } 

  updateAgentRecord(id?:number){
  console.log("id=",id);
      this.router.navigate(['update-agent']);
      this.agentservice.getId(id);
  }

  loginAgent(agents?:Agents){
    console.log("agent=",agents);
        //this.router.navigate(['update-agent']);
        this.agentservice.getAllAgent();
          }

  deleteAgentRecord(id?:number){
   // this.agentservice.getId(id);
this.agentservice.deleteAgentById(id).subscribe();
this.router.navigate(['admin']);
//console.log("id=",id);
window.location.reload();
  }

  
}
