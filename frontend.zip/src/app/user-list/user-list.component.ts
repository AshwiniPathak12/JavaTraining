import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Users } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  user?:Users[];
  constructor(private userservice:UserService,
               private router:Router) { }

  ngOnInit(): void {
    this.getAllUsers();
  }

  getAllUsers(){
    this.userservice.getAllUser().subscribe(data=>{
      this.user=data;
    });
  }

  updateUserRecord(id?:number){
    console.log("id= ",id);
    this.userservice.getId(id);
    this.router.navigate(['update-user']);
    
  }

  deleteUserRecord(id?:number){
    //this.userservice.getId(id);
    this.userservice.deleteUserById(id).subscribe();
   // this.router.navigate(['user']);
     //window.location.reload();
  }
}
