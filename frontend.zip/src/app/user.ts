export class Users {
    id?:number;
    name?:string;
    email?:string;
    dob?:string;
    address?:string;
    gender?:string;
    password?:string;

    loggedIn?:boolean;
}
