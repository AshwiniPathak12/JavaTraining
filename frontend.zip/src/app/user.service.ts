import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Agent } from 'http';
import { Observable } from 'rxjs';
import { Agents } from './agent';
import { Users } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
id?:number;
  baseurl="http://localhost:8089/User/getuser";
  constructor(private httpClient:HttpClient) { }
//get all insurance
getAllUser():Observable<Users[]>{
  return this.httpClient.get<Users[]>(`${this.baseurl}`);
}

//add

addAllUser(users?:Users):Observable<Object>{
  return this.httpClient.post<Object>("http://localhost:8089/User/saveuser",users);
}

//http://localhost:8089/User/getuser/2

//get user by id
getId(getid?:number){
  this.id=getid;
  }    
    getUserById():Observable<Object>{
      return this.httpClient.get<Object>(`${this.baseurl}/${this.id}`);
    }
//update 
baseurl2="http://localhost:8089/User/updateuser";
updateUser(user?:Users):Observable<Object>{
  return this.httpClient.put<Object>(`${this.baseurl2}/${this.id}`,user);
}

//delete 
baseurl3="http://localhost:8089/User/delete";
deleteUserById(id?:number):Observable<Object>{
  return this.httpClient.delete<Object>(`${this.baseurl3}/${this.id}`);
}


//login User

loginAgent(user?:Users):Observable<Object>{
  return this.httpClient.post<Object>(`http://localhost:8089/User/login`,user);
}



}
