import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Buyprocess2Component } from './buyprocess2.component';

describe('Buyprocess2Component', () => {
  let component: Buyprocess2Component;
  let fixture: ComponentFixture<Buyprocess2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Buyprocess2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Buyprocess2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
