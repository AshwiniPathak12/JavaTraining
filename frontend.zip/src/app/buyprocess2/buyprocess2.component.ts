import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FileUploadService } from '../file-upload.service';

@Component({
  selector: 'app-buyprocess2',
  templateUrl: './buyprocess2.component.html',
  styleUrls: ['./buyprocess2.component.css']
})
export class Buyprocess2Component implements OnInit {

      // // Variable to store shortLink from api response
      // shortLink: string = "";
      // loading: boolean = false; // Flag variable
      // file: File = null; // Variable to store file

  constructor(private router:Router,
    private fileUploadService: FileUploadService) { }

  ngOnInit(): void {
  }


  pay(){
    this.router.navigateByUrl('/payment');
  }

 
}

