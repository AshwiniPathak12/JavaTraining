import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buypolicy1',
  templateUrl: './buypolicy1.component.html',
  styleUrls: ['./buypolicy1.component.css']
})
export class Buypolicy1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
