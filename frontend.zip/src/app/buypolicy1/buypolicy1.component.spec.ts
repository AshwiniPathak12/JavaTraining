import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Buypolicy1Component } from './buypolicy1.component';

describe('Buypolicy1Component', () => {
  let component: Buypolicy1Component;
  let fixture: ComponentFixture<Buypolicy1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Buypolicy1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Buypolicy1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
