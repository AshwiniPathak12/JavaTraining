import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Insurance } from '../insurance';
import { InsuranceService } from '../insurance.service';

@Component({
  selector: 'app-update-insurance',
  templateUrl: './update-insurance.component.html',
  styleUrls: ['./update-insurance.component.css']
})
export class UpdateInsuranceComponent implements OnInit {
insurance:Insurance=new Insurance();
  constructor(private router:Router,
    private insuranceservice:InsuranceService) { }

  ngOnInit(): void {
    this.getInsuranceById();
  }

  updateInsurance(id?:number){
    console.log(this.insurance);
    alert("successfully updated...!!")
    this.insuranceservice.updateInsurance(this.insurance).subscribe();
    this.router.navigate(['update-insurance']);
  }

  getInsuranceById(){
    this.insuranceservice.getInsuranceById().subscribe(data=>{
      this.insurance=data;
    });
  }

  
}
