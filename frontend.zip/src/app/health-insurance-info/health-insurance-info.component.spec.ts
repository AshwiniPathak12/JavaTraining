import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HealthInsuranceInfoComponent } from './health-insurance-info.component';

describe('HealthInsuranceInfoComponent', () => {
  let component: HealthInsuranceInfoComponent;
  let fixture: ComponentFixture<HealthInsuranceInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HealthInsuranceInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HealthInsuranceInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
