import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-health-insurance-info',
  templateUrl: './health-insurance-info.component.html',
  styleUrls: ['./health-insurance-info.component.css']
})
export class HealthInsuranceInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
