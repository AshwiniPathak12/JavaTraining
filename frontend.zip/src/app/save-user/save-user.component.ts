import { Component, OnInit } from '@angular/core';
import { Users } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-save-user',
  templateUrl: './save-user.component.html',
  styleUrls: ['./save-user.component.css']
})
export class SaveUserComponent implements OnInit {
users:Users=new Users();
  constructor(private userservice:UserService) { }

  ngOnInit(): void {
    
  }

  saveuser(){
    this.userservice.addAllUser(this.users).subscribe();
    alert("Success...!!");
    
  }

}
