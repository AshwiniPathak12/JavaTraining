import { Component, OnInit } from '@angular/core';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-save-admin',
  templateUrl: './save-admin.component.html',
  styleUrls: ['./save-admin.component.css']
})
export class SaveAdminComponent implements OnInit {
admin:Admin=new Admin();
  constructor(private adminservice:AdminService) { }

  ngOnInit(): void {
    //this.loginAdmin();
  }


  saveadmin(){
    console.log(this.admin);
    
    this.adminservice.addAdmin(this.admin).subscribe();
    
    alert("Success...!!");
  }

  // loginAdmin(){
  // console.log(this.admin);
  // const result=this.adminservice.loginAdmin(this.admin).subscribe();
  // console.log("Hello");
  // console.log(result);
  // alert("Success...!!!!");
  // }
}
