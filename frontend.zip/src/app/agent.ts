export class Agents {

    id?:number;
    name?:string;
    commission?:string;

    loggedIn?:boolean;
    email?:string;
    password?:string;
}
