import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Insurance } from '../insurance';
import { InsuranceService } from '../insurance.service';

@Component({
  selector: 'app-policy-list',
  templateUrl: './policy-list.component.html',
  styleUrls: ['./policy-list.component.css']
})
export class PolicyListComponent implements OnInit {
insurance?:Insurance[];
  constructor(private router:Router,
              private insuranceservice:InsuranceService) { }

  ngOnInit(): void {
    this.getAllInsurance();
  }


  getAllInsurance(){
    this.insuranceservice.getAllInsurance().subscribe(data=>{
      this.insurance=data;
    });
  }

  updateInsuranceRecord(id?:number){
    console.log("id= ",id);
    this.insuranceservice.getId(id);
    this.router.navigate(['update-insurance']);
  }

  deleteInsuranceRecord(id?:number){
    //this.insuranceservice.getId(id);
    this.insuranceservice.deleteInsuranceById(id).subscribe();
    //this.router.navigate(['']);
    //window.location.reload();
  }
}
