import { Component, OnInit } from '@angular/core';
import { Insurance } from '../insurance';
import { InsuranceService } from '../insurance.service';

@Component({
  selector: 'app-save-insurance',
  templateUrl: './save-insurance.component.html',
  styleUrls: ['./save-insurance.component.css']
})
export class SaveInsuranceComponent implements OnInit {
insurance:Insurance=new Insurance();

  constructor(private insuranceservice:InsuranceService) { }

  ngOnInit(): void {
  }

  saveInsurance(){
    console.log(this.insurance);
    this.insuranceservice.addInsurance(this.insurance).subscribe();
  }
}
