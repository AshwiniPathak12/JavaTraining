import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GetInsuranceComponent } from './get-insurance/get-insurance.component';
import { HttpClientModule } from '@angular/common/http';
import { SaveInsuranceComponent } from './save-insurance/save-insurance.component';
import { FormsModule } from '@angular/forms';
import { UpdateInsuranceComponent } from './update-insurance/update-insurance.component';
import { LoginbuttonComponent } from './loginbutton/loginbutton.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AgentSignupComponent } from './agent-signup/agent-signup.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { AdminListComponent } from './admin-list/admin-list.component';
import { AgentListComponent } from './agent-list/agent-list.component';
import { UserListComponent } from './user-list/user-list.component';
import { SaveAdminComponent } from './save-admin/save-admin.component';
import { SaveAgentComponent } from './save-agent/save-agent.component';
import { SaveUserComponent } from './save-user/save-user.component';
import { UpdateAdminComponent } from './update-admin/update-admin.component';
import { UpdateAgentComponent } from './update-agent/update-agent.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { PolicyListComponent } from './policy-list/policy-list.component';
import { AdminLoginFormComponent } from './admin-login-form/admin-login-form.component';
import { AdminOptionLoginComponent } from './admin-option-login/admin-option-login.component';
import { AgentLoginFormComponent } from './agent-login-form/agent-login-form.component';
import { AgentOptionLoginFormComponent } from './agent-option-login-form/agent-option-login-form.component';
import { UserLoginFormComponent } from './user-login-form/user-login-form.component';
import { UserOptionLoginComponent } from './user-option-login/user-option-login.component';
import { Buypolicy1Component } from './buypolicy1/buypolicy1.component';
import { Buyprocess2Component } from './buyprocess2/buyprocess2.component';
import { Buyprocess3Component } from './buyprocess3/buyprocess3.component';
import { PaymentComponent } from './payment/payment.component';
import { AgentPolicyListViewRoleComponent } from './agent-policy-list-view-role/agent-policy-list-view-role.component';
import { HealthInsuranceInfoComponent } from './health-insurance-info/health-insurance-info.component';


@NgModule({
  declarations: [
    AppComponent,
    GetInsuranceComponent,
    SaveInsuranceComponent,
    UpdateInsuranceComponent,
    LoginbuttonComponent,
    AdminloginComponent,
    AgentSignupComponent,
    UserSignupComponent,
    AdminListComponent,
    AgentListComponent,
    UserListComponent,
    SaveAdminComponent,
    SaveAgentComponent,
    SaveUserComponent,
    UpdateAdminComponent,
    UpdateAgentComponent,
    UpdateUserComponent,
    PolicyListComponent,
    AdminLoginFormComponent,
    AdminOptionLoginComponent,
    AgentLoginFormComponent,
    AgentOptionLoginFormComponent,
    UserLoginFormComponent,
    UserOptionLoginComponent,
    Buypolicy1Component,
    Buyprocess2Component,
    Buyprocess3Component,
    PaymentComponent,
    AgentPolicyListViewRoleComponent,
    HealthInsuranceInfoComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
