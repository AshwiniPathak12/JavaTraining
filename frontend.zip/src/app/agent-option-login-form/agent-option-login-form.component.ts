import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-option-login-form',
  templateUrl: './agent-option-login-form.component.html',
  styleUrls: ['./agent-option-login-form.component.css']
})
export class AgentOptionLoginFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
