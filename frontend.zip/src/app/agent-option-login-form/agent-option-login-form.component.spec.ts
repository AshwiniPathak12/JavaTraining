import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentOptionLoginFormComponent } from './agent-option-login-form.component';

describe('AgentOptionLoginFormComponent', () => {
  let component: AgentOptionLoginFormComponent;
  let fixture: ComponentFixture<AgentOptionLoginFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgentOptionLoginFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentOptionLoginFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
