import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-option-login',
  templateUrl: './user-option-login.component.html',
  styleUrls: ['./user-option-login.component.css']
})
export class UserOptionLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
