import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserOptionLoginComponent } from './user-option-login.component';

describe('UserOptionLoginComponent', () => {
  let component: UserOptionLoginComponent;
  let fixture: ComponentFixture<UserOptionLoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserOptionLoginComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserOptionLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
