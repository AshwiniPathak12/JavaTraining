import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Insurance } from './insurance';

@Injectable({
  providedIn: 'root'
})
export class InsuranceService {

  constructor(private httpclient:HttpClient) { }
//basrURL="http://localhost:8089/Insurance/getinsurance";


  //get all insurance
  getAllInsurance():Observable<Insurance[]>{

    return this.httpclient.get<Insurance[]>('http://localhost:8089/Insurance/getinsurance');
  }

  //save insurance
  addInsurance(insurance?:Insurance):Observable<Object>{
    return this.httpclient.post<Object>('http://localhost:8089/Insurance/saveinsurance',insurance);
}
id?:number;
//update
//http://localhost:8089/Insurance/updateinsurances/2
 //get insurance by id
getId(getId?:number){
  this.id=getId;  
  }  
  
    baseurl2="http://localhost:8089/Insurance/getinsurance"
  
    getInsuranceById(id?:number):Observable<Object>{  
      return this.httpclient.get<Object>(`${this.baseurl2}/${this.id}`);  
    }
    
    baseurl1="http://localhost:8089/Insurance/updateinsurances";
updateInsurance(insurance?:Insurance):Observable<Object>{
    return this.httpclient.put<Object>(`${this.baseurl1}/${this.id}`,insurance);
  }

  //delete

  baseurl3="http://localhost:8089/Insurance/delete";
  deleteInsuranceById(id?:number):Observable<Object>{
    return this.httpclient.delete<Object>(`${this.baseurl3}/${this.id}`);
  }



}