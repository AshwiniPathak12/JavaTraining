import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { AdminListComponent } from '../admin-list/admin-list.component';
@Component({
  selector: 'app-loginbutton',
  templateUrl: './loginbutton.component.html',
  styleUrls: ['./loginbutton.component.css']
})
export class LoginbuttonComponent implements OnInit {

  username:string="";

  password:string="";

  msg:string="";

  
  CheckLogin(){

    if(this.username=="admin" && this.password=="admin123"){
      this.msg="valid credentials";
      // this.router.navigate(['header'])
       //login is use for show the admin details
       this.router.navigate(['admin-list']);
    }
    else{
      this.msg="Invalid credentials";
    }
  }

  constructor(private router:Router) { }

  ngOnInit(): void {
    this.CheckLogin();
  }


}
