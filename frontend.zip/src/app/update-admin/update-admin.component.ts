import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-update-admin',
  templateUrl: './update-admin.component.html',
  styleUrls: ['./update-admin.component.css']
})
export class UpdateAdminComponent implements OnInit {
admin:Admin=new Admin();
  constructor(private router:Router,private admin_service:AdminService) { }

  ngOnInit(): void {
    this.getAdminByID();
  }

  
  getAdminByID(){
    this.admin_service.getAdminById().subscribe(data=>{
      this.admin=data;
    });
  }

  updateadmin(id?:number){ 
    console.log(this.admin);
    this.admin_service.updateAdmin(this.admin).subscribe();
    this.router.navigate(['update-admin']);
  }


}
