export class Insurance {
   

        id?: number;
        claimnumber?:string;
        email?:string
        insurancenumber?:string;
        insurancepremiumamount?:string;    
        status?:string;
    
}
