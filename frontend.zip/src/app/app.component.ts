import { Component } from '@angular/core';
import { Injectable, ErrorHandler } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
 

})
export class AppComponent {
  title = 'insurance6';
  
}
