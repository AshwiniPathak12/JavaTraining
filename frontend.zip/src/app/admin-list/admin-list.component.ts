import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';
import { UpdateAdminComponent } from '../update-admin/update-admin.component';

@Component({
  selector: 'app-admin-list',
  templateUrl: './admin-list.component.html',
  styleUrls: ['./admin-list.component.css']
})
export class AdminListComponent implements OnInit {

  admin?:Admin[];
  constructor(private adminservice:AdminService,private router:Router) { }

  ngOnInit(): void {
    // this.admin=[
    //   {
    //     id:1,
    //     name:"mona"
    //   },
    //   {
    //     id:2,
    //     name:"ashu"
    //   }
    // ];
    this.getAllAdmins();
  }
getAllAdmins(){
  this.adminservice.getAllAdmin().subscribe(data=>{
    this.admin=data;
  });
}

upadteAdminRecord(id?:number){
console.log("id",id);
this.adminservice.getId(id);
 this.router.navigate(['update-admin']);
   
}

deleteAdminRecord(id?:number){
this.adminservice.deleteAdminById(id).subscribe();
this.router.navigate(['admin']);
console.log("id=",id);
//window.location.reload();
}



}

