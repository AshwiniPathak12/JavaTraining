import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admin-login-form',
  templateUrl: './admin-login-form.component.html',
  styleUrls: ['./admin-login-form.component.css']
})
export class AdminLoginFormComponent implements OnInit {
  admin:Admin=new Admin();
  constructor(private router:Router,
    private adminservice:AdminService) { }

  ngOnInit(): void {
    this.loginAdmin();
  }


  checkadminlogin(){
    console.log(this.admin);    
  // var result= this.adminservice.loginAdmin(this.admin).subscribe();
    //alert("Success...!!");
    //console.log("Hello");
   // console.log("sfasdf",result);
   // this.router.navigate(['admin-option-login']);
   
   var result= this.adminservice.loginAdmin(this.admin).subscribe(response => {
    
    console.log(response);
   
    console.log(response);
    if(response=="SUCCESS")    
    {
   
     this.router.navigateByUrl('/admin-option-login');
    
    }
    else{
      alert("enter valid creditial");
    }
     
  },
  error => {
   
   console.log(error);
  });
  }

  loginAdmin(admin?:Admin){
   //console.log("id",id);
    var result=this.adminservice.getAllAdmin();
    console.log("sds",result);
   //  this.router.navigate(['admin']);
       
    }
}
