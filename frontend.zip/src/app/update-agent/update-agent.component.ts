import { Component, OnInit } from '@angular/core';
import { Agent } from 'http';
import { AgentSignupComponent } from '../agent-signup/agent-signup.component';
import { Agents } from '../agent';
// import { Agent } from '../agent';
import { AgentService } from '../agent.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-agent',
  templateUrl: './update-agent.component.html',
  styleUrls: ['./update-agent.component.css']
})
export class UpdateAgentComponent implements OnInit {
//agents:Agent=new Agents();
  agent:Agents=new Agents();
  //adjustment
  //agents!: Object;
  constructor(private router:Router,
             private agentservice:AgentService) { }

  ngOnInit(): void {
    this.getAgentById();
  }

  updateagent(){
    console.log(this.agent);
    alert("successfully updated...!!!");
    this.agentservice.updateAgent(this.agent).subscribe();
        this.router.navigate(['update-agent']);
  }

  getAgentById(){
    this.agentservice.getAgentById().subscribe(data=>{
      this.agent=data;
    });
  }
}
