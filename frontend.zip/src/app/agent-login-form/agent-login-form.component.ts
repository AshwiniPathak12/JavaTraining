import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Agents } from '../agent';
import { AgentService } from '../agent.service';
import { Users } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-agent-login-form',
  templateUrl: './agent-login-form.component.html',
  styleUrls: ['./agent-login-form.component.css']
})
export class AgentLoginFormComponent implements OnInit {
  agent:Agents=new Agents();
  agents!: any;
  constructor(private router:Router,
    private agentservice:AgentService) { }

  ngOnInit(): void {
    //this.loginAgent();
   
  }  

  checkagentlogin(){
    console.log(this.agent);    
    this.router.navigate(['agent-option-login-form']);

    //var result= this.agentservice.loginAgent(this.agents).subscribe(response => {
    var result= this.agentservice.loginAgent(this.agent).subscribe(response => {
    
      console.log(response);
     
      console.log(response);
      if(response=="SUCCESS") 
      {     
       this.router.navigateByUrl('/agent-option-login');      
      }
      else{
        alert("enter valid creditial");
       this.router.navigateByUrl('/agent-login-form');
      }       
    },
    error => {     
     //console.log(error);
    });
  }

  loginAgent(agent?:Agents){
    //console.log("id",id);
     var result=this.agentservice.getAllAgent();
     console.log("sds",result);
    //  this.router.navigate(['admin']);
        
     }
 }
