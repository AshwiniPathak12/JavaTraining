import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Buyprocess3Component } from './buyprocess3.component';

describe('Buyprocess3Component', () => {
  let component: Buyprocess3Component;
  let fixture: ComponentFixture<Buyprocess3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Buyprocess3Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Buyprocess3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
