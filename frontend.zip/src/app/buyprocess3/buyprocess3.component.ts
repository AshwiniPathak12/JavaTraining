import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyprocess3',
  templateUrl: './buyprocess3.component.html',
  styleUrls: ['./buyprocess3.component.css']
})
export class Buyprocess3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
