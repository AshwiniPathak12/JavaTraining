export class Admin {
id?:number;
name?:string;


loggedIn?:boolean;
email?:string;
password?:string;

}

