import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Admin } from './admin';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
 id?:number;
  baseurl="http://localhost:8089/Admin/getadmin";
  baseurl1="http://localhost:8089/Admin/updateadmin";

  constructor(private httpclient:HttpClient) { }
//get all admin
  getAllAdmin():Observable<Admin[]>{   
    return this.httpclient.get<Admin[]>(`${this.baseurl}`);
  }

  //add admin
  addAdmin( admin?:Admin):Observable<Object>{
    return this.httpclient.post<Object>("http://localhost:8089/Admin/saveadmin",admin);
  }
//get admin by id

  //http://localhost:8089/Admin/getadmin/2
   getId(getid?:number){
        this.id=getid;
   }

  getAdminById(id?:number):Observable<Object>{  
    return this.httpclient.get<Object>(`${this.baseurl}/${this.id}`);
  }

  //update

  updateAdmin(admin?:Admin):Observable<Object>{
    return this.httpclient.put<Object>(`${this.baseurl1}/${this.id}`,admin);
  }

//delete admin by id

baseurl3="http://localhost:8089/Admin/delete";
deleteAdminById(id?:number):Observable<Object>{
  console.log(id);
  return this.httpclient.delete<Object>(`${this.baseurl3}/${id}`);
}

//login admin
//loginAdmin
loginAdmin(admin?:Admin):Observable<Object>{
  return this.httpclient.post<Object>("http://localhost:8089/Admin/login",admin);
}
}