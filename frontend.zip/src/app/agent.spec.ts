import { Agents } from './agent';

describe('Agent', () => {
  it('should create an instance', () => {
    expect(new Agents()).toBeTruthy();
  });
});
