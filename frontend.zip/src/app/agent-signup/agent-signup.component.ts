import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-signup',
  templateUrl: './agent-signup.component.html',
  styleUrls: ['./agent-signup.component.css']
})
export class AgentSignupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
