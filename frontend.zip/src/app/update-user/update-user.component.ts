import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Users } from '../user';
import { UserListComponent } from '../user-list/user-list.component';
import { UserService } from '../user.service';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {
users:Users=new Users();
  constructor(private router:Router,
             private userservice:UserService) { }

  ngOnInit(): void {
    this.getUserById();
  }

  updateuser(id?:number){
console.log(this.users);
alert("successfully updated...!!!");
this.userservice.updateUser(this.users).subscribe();
this.router.navigate(['update-user']);

  }

  getUserById(){
    this.userservice.getUserById().subscribe(data=>{
      this.users=data;
    })
  }

  

}
